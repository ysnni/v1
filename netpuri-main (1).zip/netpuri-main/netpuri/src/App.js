import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Homepage from './pages/HomePage'
import Filtering from './pages/Filtering'
import Fishing from './pages/Fishing'
import Siteinfo from './pages/Siteinfo'

const App = () => {
  return (
      <div className='App'>
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="/sub" element={<Filtering />} />
          <Route path="/sub2" element={<Fishing />} />
          <Route path="/sub3" element={<Siteinfo />} />
        </Routes>
      </div>
  );
};

export default App;