import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Fishing.module.css';

const Fishing = () => {

    return (
        <div>

            <nav>
                <div className={styles.name}>WebCleanser</div>
                <div className={styles.close}>⨉</div>
            </nav>

            <div className={styles.menuContainer}>
            <div className={styles.unselectedMenu}>
                <Link to="/sub" style={{textDecoration: "none"}}>
                    <div className={`${styles.menu} ${styles.filteringMenu}`}>필터링</div>
                </Link>
                </div>
                <div className={styles.selectedMenu}>
                    <Link to="/sub2" style={{textDecoration: "none"}}>
                        <div className={`${styles.menu} ${styles.fishingMenu}`}>피싱 사이트 감지</div>
                    </Link>
                </div>
            </div>

            <div className={styles.offAlarm}>
                <p className={styles.closeButton}>⨉</p>
                <div className={styles.block}>
                    <p className={styles.blockAlarm}>피싱사이트 차단이 현재 꺼져있습니다.</p>
                    <p className={styles.blockDetail}>개인정보 보호를 위해 피싱사이트 차단 활성화를 추천합니다.</p>
                </div>
            </div>

            <div className={styles.order}>
                <div className={styles.orderDanger}>위험도순</div>
                <div className={styles.orderButton}>∨</div>
            </div>

            <div className={styles.linkBox}>
                <div className={styles.siteListContainer}>
                    <Link to="/sub3" style={{textDecoration: "none"}}>
                    <div className={styles.siteContainer}>
                        <div className={styles.siteThumbNail}></div>
                        <div className={styles.detailsContainer}>
                            <div className={styles.siteDetails}>일본 데이터 e심 - Google 검색</div>
                            <div className={styles.siteLinks}>google.co.kr/search?q_src=google/jdkfjsdd</div>
                        </div>
                    </div>
                    </Link>
                    <div className={styles.buttonContainer}>
                        <div className={styles.virusButton}>✓ 바이러스</div>
                        <div className={styles.trackingButton}>✓ 트래킹</div>
                        <div className={styles.malwareButton}>✓ 악성코드</div>
                    </div>
                </div>

                <div className={styles.siteListContainer}>
                    <div className={styles.siteContainer}>
                        <div className={styles.siteThumbNail}></div>
                        <div className={styles.detailsContainer}>
                            <div className={styles.siteDetails}>하네다 공항에서 긴자역 가는 3가지 방법</div>
                            <div className={styles.siteLinks}>https://merici.tistory.com/entry/하네다-공항에서</div>
                        </div>
                    </div>
                    <div className={styles.buttonContainer}>
                        <div className={styles.trackingButton}>✓ 트래킹</div>
                        <div className={styles.virusButton}>✓ 바이러스</div>
                    </div>
                </div>

                <div className={styles.siteListContainer}>
                    <div className={styles.siteContainer}>
                        <div className={styles.siteThumbNail}></div>
                        <div className={styles.detailsContainer}>
                            <div className={styles.siteDetails}>최고의 디자인을 위한 3가지 습관과 원칙</div>
                            <div className={styles.siteLinks}>https://www.nhn-commerce.com/echost
                            </div>
                        </div>
                    </div>
                    <div className={styles.buttonContainer}>
                        <div className={styles.malwareButton}>✓ 악성코드</div>
                        <div className={styles.trackingButton}>✓ 트래킹</div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default Fishing;